# Housing Helper Realty

A simple real-estate website for property enquiries, site visits and residential listings in Vasai, Virar and surrounding areas.

## Website
Open `index.html` in a browser or publish this repository using GitHub Pages.

## Contact
WhatsApp: +91 75229 65874
